package com.example.olamundo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tela: TextView = findViewById(R.id.tela)
        val button0: Button = findViewById(R.id.button0)
        val button1: Button = findViewById(R.id.button1)
        val button2: Button = findViewById(R.id.button2)
        val button3: Button = findViewById(R.id.button3)
        val button4: Button = findViewById(R.id.button4)
        val button5: Button = findViewById(R.id.button5)
        val button6: Button = findViewById(R.id.button6)
        val button7: Button = findViewById(R.id.button7)
        val button8: Button = findViewById(R.id.button8)
        val button9: Button = findViewById(R.id.button9)
        val buttonC: Button = findViewById(R.id.buttonC)
        val buttonDot: Button = findViewById(R.id.buttonDot)
        val buttonPlus: Button = findViewById(R.id.buttonPlus)
        val buttonMinus: Button = findViewById(R.id.buttonMinus)
        val buttonMult: Button = findViewById(R.id.buttonMult)
        val buttonDivisor: Button = findViewById(R.id.buttonDivisor)
        val buttonEquals: Button = findViewById(R.id.buttonEquals)

        var mem1 :Double = 0.0;
        var mem2 : Double = 0.0;
        var memResult : Double = 0.0;
        var memOp : Int = 0; // 1 = +; 2 = -; 3 = *; 4 = /

        button0.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "0";
            } else {
                tela.append("0");
            }
        }

        button1.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "1";
            } else {
                tela.append("1");
            }
        }

        button2.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "2";
            } else {
                tela.append("2");
            }
        }

        button3.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "3";
            } else {
                tela.append("3");
            }
        }

        button4.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "4";
            } else {
                tela.append("4");
            }
        }

        button5.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "5";
            } else {
                tela.append("5");
            }
        }

        button6.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "6";
            } else {
                tela.append("6");
            }
        }

        button7.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "7";
            } else {
                tela.append("7");
            }
        }

        button8.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "8";
            } else {
                tela.append("8");
            }
        }

        button9.setOnClickListener {
            if (tela.text.toString() == "0") {
                tela.text = "9";
            } else {
                tela.append("9");
            }
        }

        buttonC.setOnClickListener {
            tela.text = "0";
            memOp = 0;
            mem1 = 0.0;
            mem2 = 0.0;
            memResult = 0.0;
        }

        buttonDot.setOnClickListener {
            if ("." !in tela.text.toString()) {
                tela.append(".");
            }
        }

        buttonPlus.setOnClickListener() {
            mem1 = tela.text.toString().toDouble();
            memOp = 1;
            tela.text = "0"
        }

        buttonMinus.setOnClickListener() {
            mem1 = tela.text.toString().toDouble();
            memOp = 2;
            tela.text = "0"
        }

        buttonMult.setOnClickListener() {
            mem1 = tela.text.toString().toDouble();
            memOp = 3;
            tela.text = "0"
        }

        buttonDivisor.setOnClickListener() {
            mem1 = tela.text.toString().toDouble();
            memOp = 4;
            tela.text = "0"
        }

        buttonEquals.setOnClickListener() {
            mem2 = tela.text.toString().toDouble();

            if (memOp == 1) {
                memResult = mem1 + mem2;
            } else

            if (memOp == 2) {
                memResult = mem1 - mem2;
            } else

            if (memOp == 3) {
                memResult = mem1 * mem2;
            } else

            if (memOp == 4) {
                memResult = mem1 / mem2;
            }

            tela.text = memResult.toString();
            memOp = 0;
            mem1 = 0.0;
            mem2 = 0.0;
            memResult = 0.0;
        }
    }

}
